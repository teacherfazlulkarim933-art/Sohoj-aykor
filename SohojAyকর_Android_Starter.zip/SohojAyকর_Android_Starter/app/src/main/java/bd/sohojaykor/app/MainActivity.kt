package bd.sohojaykor.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private const val ETAX_URL = "https://etaxnbr.gov.bd/"
private const val NBR_FAQ_URL = "https://nbr.gov.bd/faq/income-tax-faq"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SohojAyকরApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SohojAyকরApp() {
    var page by remember { mutableStateOf("home") }
    val context = LocalContext.current
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF087A52))) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("সহজ আয়কর", fontWeight = FontWeight.Bold)
                        Text("বাংলাদেশের করদাতাদের সহায়তায়", style = MaterialTheme.typography.labelSmall)
                    }
                })
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                when (page) {
                    "zero" -> {
                        Text("জিরো রিটার্ন: প্রাথমিক ধারণা", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Text("‘জিরো রিটার্ন’ কথাটি প্রচলিতভাবে ব্যবহার করা হলেও, রিটার্নে প্রকৃত আয়, করযোগ্য আয়, কর ও সম্পদ-দায়ের তথ্য সঠিকভাবে দেখাতে হয়। আয় বা কর শূন্য হলেই সব তথ্য ফাঁকা বা শূন্য লিখতে হবে—এমন নয়।")
                        Spacer(Modifier.height(10.dp))
                        Text("প্রস্তুতির সাধারণ ধাপ", fontWeight = FontWeight.Bold)
                        listOf("TIN ও e-Return অ্যাকাউন্টের তথ্য প্রস্তুত রাখুন।", "বেতন/ব্যবসা/ভাড়া/অন্যান্য আয়ের কাগজপত্র মিলিয়ে নিন।", "উৎসে কর্তিত কর, অগ্রিম কর, বিনিয়োগ ও সম্পদ-দায়ের তথ্য যাচাই করুন।", "NBR-এর e-Return পোর্টালে নির্দেশনা অনুযায়ী তথ্য পূরণ করুন।", "সাবমিটের আগে সম্পূর্ণ রিটার্ন ভালোভাবে যাচাই করুন।").forEach { Bullet(it) }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ETAX_URL))) }) { Text("সরকারি e-Return পোর্টাল খুলুন") }
                        OutlinedButton(onClick = { page = "home" }) { Text("হোমে ফিরুন") }
                    }
                    "docs" -> {
                        Text("প্রয়োজনীয় কাগজপত্র", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        listOf("e-TIN ও জাতীয় পরিচয়পত্রের তথ্য", "বেতন সনদ/বেতন বিবরণী", "ব্যাংক সুদ বা মুনাফার বিবরণী", "উৎসে কর কর্তনের সনদ/প্রমাণ", "বিনিয়োগের প্রমাণ (প্রযোজ্য হলে)", "সম্পদ ও দায়ের তথ্য", "আগের বছরের রিটার্ন/কর পরিশোধের তথ্য (থাকলে)").forEach { Bullet(it) }
                        Text("আপনার ক্ষেত্রে যে কাগজপত্র প্রযোজ্য, শুধু সেগুলো প্রস্তুত রাখুন।")
                        OutlinedButton(onClick = { page = "home" }) { Text("হোমে ফিরুন") }
                    }
                    "links" -> {
                        Text("সরকারি তথ্য ও সহায়তা", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ETAX_URL))) }) { Text("NBR e-Return") }
                        OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(NBR_FAQ_URL))) }) { Text("NBR আয়কর FAQ") }
                        Text("NBR e-Return সহায়তা নম্বর: 09643717171")
                        OutlinedButton(onClick = { page = "home" }) { Text("হোমে ফিরুন") }
                    }
                    else -> {
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("সহজ ভাষায় আয়কর বুঝুন", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("রিটার্ন প্রস্তুতি, প্রয়োজনীয় কাগজপত্র ও সরকারি লিংক—এক জায়গায়।")
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        MenuCard("জিরো রিটার্ন নির্দেশিকা", "কীভাবে তথ্য প্রস্তুত করবেন", onClick = { page = "zero" })
                        MenuCard("প্রয়োজনীয় কাগজপত্র", "রিটার্নের আগে কী কী লাগতে পারে", onClick = { page = "docs" })
                        MenuCard("সরকারি ওয়েবসাইট ও সহায়তা", "NBR e-Return ও FAQ", onClick = { page = "links" })
                        MenuCard("আয়কর ক্যালকুলেটর", "পরবর্তী সংস্করণে যুক্ত হবে", enabled = false, onClick = {})
                        Spacer(Modifier.height(16.dp))
                        Text("গুরুত্বপূর্ণ সতর্কতা", fontWeight = FontWeight.Bold)
                        Text("এই অ্যাপটি সাধারণ তথ্য সহায়তার জন্য। এটি NBR-এর সরকারি অ্যাপ নয় এবং কর পরামর্শের বিকল্প নয়। করের হার, ছাড় ও ন্যূনতম কর অর্থবছর/করবর্ষ অনুযায়ী বদলাতে পারে। রিটার্ন জমার আগে সর্বশেষ NBR নির্দেশনা যাচাই করুন।")
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuCard(title: String, subtitle: String, enabled: Boolean = true, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), onClick = onClick, enabled = enabled) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Bullet(text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text("•  ", fontWeight = FontWeight.Bold)
        Text(text)
    }
}
